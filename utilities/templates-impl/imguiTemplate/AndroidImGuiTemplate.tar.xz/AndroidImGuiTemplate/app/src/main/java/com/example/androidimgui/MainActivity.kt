package com.example.androidimgui

import android.app.NativeActivity
import android.os.Bundle
import android.view.KeyEvent
import android.view.inputmethod.InputMethodManager
import java.util.concurrent.LinkedBlockingQueue

class MainActivity : NativeActivity() {
    private val unicodeCharacterQueue = LinkedBlockingQueue<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    fun showSoftInput() {
        val systemService = getSystemService(INPUT_METHOD_SERVICE)
        if (systemService != null) {
            val inputMethodManager = systemService as InputMethodManager
            inputMethodManager.showSoftInput(window.decorView, 0)
            return
        }
        throw NullPointerException("null cannot be cast to non-null type android.view.inputmethod.InputMethodManager")
    }

    fun hideSoftInput() {
        val systemService = getSystemService(INPUT_METHOD_SERVICE)
        if (systemService != null) {
            val inputMethodManager = systemService as InputMethodManager
            inputMethodManager.hideSoftInputFromWindow(window.decorView.windowToken, 0)
            return
        }
        throw NullPointerException("null cannot be cast to non-null type android.view.inputmethod.InputMethodManager")
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            unicodeCharacterQueue.offer(event.getUnicodeChar(event.metaState))
        }
        return super.dispatchKeyEvent(event)
    }

    fun pollUnicodeChar(): Int {
        return unicodeCharacterQueue.poll() ?: 0
    }
}