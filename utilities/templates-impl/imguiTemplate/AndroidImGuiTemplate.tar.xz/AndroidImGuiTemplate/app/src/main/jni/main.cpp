#include <imgui.h>
#include <imgui_impl_android.h>
#include <imgui_impl_opengl3.h>
#include <android/log.h>
#include <android_native_app_glue.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <DroidSansFallback.h>

// Data
static EGLDisplay g_EglDisplay = EGL_NO_DISPLAY;
static EGLSurface g_EglSurface = EGL_NO_SURFACE;
static EGLContext g_EglContext = EGL_NO_CONTEXT;
static struct android_app *g_App = NULL;
static bool g_Initialized = false;
static char g_LogTag[] = "ImGuiExample";
static bool g_Stop = false;

// Forward declarations
static int ShowSoftKeyboardInput();
static int PollUnicodeChars();
static void Layout_Main();
static void SetupDarkStyle();

// Dark theme + translucent matte + rounded corners are all unified
void SetupDarkStyle()
{
	ImGuiStyle & style = ImGui::GetStyle();

	// Uniform fillet (all corners are the same)
	const float R = 22.0f;

	// Translucent background
	style.Colors[ImGuiCol_WindowBg] = ImVec4(0.10f, 0.10f, 0.12f, 0.35f);
	style.Colors[ImGuiCol_ChildBg] = ImVec4(0.14f, 0.14f, 0.16f, 0.35f);
	style.Colors[ImGuiCol_FrameBg] = ImVec4(0.20f, 0.20f, 0.23f, 0.40f);
	style.Colors[ImGuiCol_PopupBg] = ImVec4(0.15f, 0.15f, 0.17f, 0.40f);

	// button
	style.Colors[ImGuiCol_Button] = ImVec4(0.18f, 0.48f, 0.70f, 0.90f);
	style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.24f, 0.56f, 0.80f, 0.90f);
	style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.14f, 0.40f, 0.62f, 0.90f);

	// Highlight
	style.Colors[ImGuiCol_CheckMark] = ImVec4(0.28f, 0.72f, 1.00f, 1.00f);
	style.Colors[ImGuiCol_SliderGrab] = ImVec4(0.28f, 0.72f, 1.00f, 1.00f);
	style.Colors[ImGuiCol_SliderGrabActive] = ImVec4(0.18f, 0.62f, 0.95f, 1.00f);
	style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.26f, 0.26f, 0.29f, 0.90f);
	style.Colors[ImGuiCol_FrameBgActive] = ImVec4(0.32f, 0.32f, 0.35f, 0.90f);

	// text
	style.Colors[ImGuiCol_Text] = ImVec4(0.94f, 0.94f, 0.94f, 1.00f);
	style.Colors[ImGuiCol_TextDisabled] = ImVec4(0.50f, 0.50f, 0.50f, 1.00f);

	// Bezel
	style.Colors[ImGuiCol_Border] = ImVec4(0.36f, 0.36f, 0.40f, 0.70f);
	style.Colors[ImGuiCol_Separator] = ImVec4(0.30f, 0.30f, 0.34f, 0.70f);

	// Title bar
	style.Colors[ImGuiCol_TitleBg] = ImVec4(0.12f, 0.12f, 0.14f, 1.00f);
	style.Colors[ImGuiCol_TitleBgActive] = ImVec4(0.18f, 0.38f, 0.60f, 1.00f);

	// ========== All rounded corners are unified ==========
	style.WindowRounding = R;
	style.ChildRounding = R;
	style.FrameRounding = R;
	style.PopupRounding = R;
	style.TabRounding = R;

	style.WindowBorderSize = 0.0f;
	style.FrameBorderSize = 0.0f;

	style.WindowPadding = ImVec2(16, 16);
	style.FramePadding = ImVec2(12, 7);
	style.ItemSpacing = ImVec2(10, 9);
}

void init(struct android_app *app)
{
	if (g_Initialized)
		return;

	g_App = app;
	ANativeWindow_acquire(g_App->window);

	// EGL
	{
		g_EglDisplay = eglGetDisplay(EGL_DEFAULT_DISPLAY);
		if (g_EglDisplay == EGL_NO_DISPLAY)
			__android_log_print(ANDROID_LOG_ERROR, g_LogTag, "eglGetDisplay failed");

		if (eglInitialize(g_EglDisplay, 0, 0) != EGL_TRUE)
			__android_log_print(ANDROID_LOG_ERROR, g_LogTag, "eglInitialize failed");

		const EGLint attrs[] = {
			EGL_BLUE_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_RED_SIZE, 8,
			EGL_DEPTH_SIZE, 24, EGL_SURFACE_TYPE, EGL_WINDOW_BIT, EGL_NONE
		};
		EGLint num_configs = 0;
		eglChooseConfig(g_EglDisplay, attrs, nullptr, 0, &num_configs);

		EGLConfig cfg;
		eglChooseConfig(g_EglDisplay, attrs, &cfg, 1, &num_configs);
		EGLint fmt;
		eglGetConfigAttrib(g_EglDisplay, cfg, EGL_NATIVE_VISUAL_ID, &fmt);
		ANativeWindow_setBuffersGeometry(g_App->window, 0, 0, fmt);

		const EGLint ctx_attrs[] = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE };
		g_EglContext = eglCreateContext(g_EglDisplay, cfg, EGL_NO_CONTEXT, ctx_attrs);
		g_EglSurface = eglCreateWindowSurface(g_EglDisplay, cfg, g_App->window, NULL);
		eglMakeCurrent(g_EglDisplay, g_EglSurface, g_EglSurface, g_EglContext);
	}

	IMGUI_CHECKVERSION();
	ImGui::CreateContext();
	ImGuiIO & io = ImGui::GetIO();
	io.IniFilename = NULL;

	SetupDarkStyle();

	ImGui_ImplAndroid_Init(g_App->window);
	ImGui_ImplOpenGL3_Init("#version 300 es");

	// Chinese font
	ImFontConfig font_cfg;
	font_cfg.FontDataOwnedByAtlas = false;
	font_cfg.SizePixels = 30.0f;
	ImFont *font = io.Fonts->AddFontFromMemoryCompressedTTF(DroidSansFallback_compressed_data,
															DroidSansFallback_compressed_size,
															font_cfg.SizePixels,
															&font_cfg,
															io.Fonts->GetGlyphRangesChineseFull());
	IM_ASSERT(font != NULL);

	ImGui::GetStyle().ScaleAllSizes(2.0f);
	g_Initialized = true;
}

void tick()
{
	if (g_Stop || g_EglDisplay == EGL_NO_DISPLAY)
		return;

	ImGuiIO & io = ImGui::GetIO();
	PollUnicodeChars();

	static bool WantTextInputLast = false;
	if (io.WantTextInput && !WantTextInputLast)
		ShowSoftKeyboardInput();
	WantTextInputLast = io.WantTextInput;

	ImGui_ImplOpenGL3_NewFrame();
	ImGui_ImplAndroid_NewFrame();
	ImGui::NewFrame();

	// Render the UI here
	Layout_Main();

	ImGui::Render();
	glViewport(0, 0, (int)io.DisplaySize.x, (int)io.DisplaySize.y);
	glClearColor(0.05f, 0.05f, 0.06f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT);
	ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
	eglSwapBuffers(g_EglDisplay, g_EglSurface);
}

void shutdown()
{
	if (!g_Initialized)
		return;

	ImGui_ImplOpenGL3_Shutdown();
	ImGui_ImplAndroid_Shutdown();
	ImGui::DestroyContext();

	if (g_EglDisplay != EGL_NO_DISPLAY)
	{
		eglMakeCurrent(g_EglDisplay, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
		if (g_EglContext != EGL_NO_CONTEXT)
			eglDestroyContext(g_EglDisplay, g_EglContext);
		if (g_EglSurface != EGL_NO_SURFACE)
			eglDestroySurface(g_EglDisplay, g_EglSurface);
		eglTerminate(g_EglDisplay);
	}

	g_EglDisplay = EGL_NO_DISPLAY;
	g_EglContext = EGL_NO_CONTEXT;
	g_EglSurface = EGL_NO_SURFACE;
	ANativeWindow_release(g_App->window);
	g_Initialized = false;
}

static void handleAppCmd(struct android_app *app, int32_t appCmd)
{
	switch (appCmd)
	{
	case APP_CMD_INIT_WINDOW:
		init(app);
		break;
	case APP_CMD_TERM_WINDOW:
		shutdown();
		break;
	}
}

static int32_t handleInputEvent(struct android_app *app, AInputEvent * inputEvent)
{
	return ImGui_ImplAndroid_HandleInputEvent(inputEvent);
}

void android_main(struct android_app *app)
{
	app->onAppCmd = handleAppCmd;
	app->onInputEvent = handleInputEvent;

	while (!g_Stop)
	{
		int out_events;
		struct android_poll_source *out_data;

		while (true)
		{
			int result =
				ALooper_pollOnce(g_Initialized ? 0 : -1, NULL, &out_events, (void **)&out_data);
			if (result == ALOOPER_POLL_TIMEOUT)
				break;
			if (result >= 0 && out_data)
				out_data->process(app, out_data);
			if (app->destroyRequested)
			{
				shutdown();
				return;
			}
		}
		tick();
	}
}

// ==========================
// Main layout 
// ==========================
void Layout_Main()
{
	ImGuiIO & io = ImGui::GetIO();

	// Set the fixed size of the window
	ImVec2 window_size(500, 300);
	ImGui::SetNextWindowSize(window_size, ImGuiCond_Once);

	// The initial location of the settings window is in the center of the screen
	// ImVec2(0.5f, 0.5f) is the anchor point (center point) of the window
	ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f), ImGuiCond_Once, ImVec2(0.5f, 0.5f));

	// Set the window flag to prevent saving the window state so that the position and size are the same every time it is launched
	ImGuiWindowFlags wflags = ImGuiWindowFlags_NoSavedSettings;
    
	// Start drawing the main window
	ImGui::Begin("Android ImGui Template : ZeroStudio", NULL, wflags);
	
	// Show "Hello World" in the window
	ImGui::SetWindowFontScale(2.5f); 
	ImGui::Text("Hello World");
	
	// More UI elements can be added here...
	
	// End the main drawing window
	ImGui::End();
}

// Input method
static int ShowSoftKeyboardInput()
{
	JavaVM *vm = g_App->activity->vm;
	JNIEnv *env;
	jint res = vm->GetEnv((void **)&env, JNI_VERSION_1_6);
	if (res == JNI_ERR)
		return -1;
	vm->AttachCurrentThread(&env, NULL);
	jclass cls = env->GetObjectClass(g_App->activity->clazz);
	jmethodID mid = env->GetMethodID(cls, "showSoftInput", "()V");
	if (mid)
		env->CallVoidMethod(g_App->activity->clazz, mid);
	vm->DetachCurrentThread();
	return 0;
}

static int PollUnicodeChars()
{
	JavaVM *vm = g_App->activity->vm;
	JNIEnv *env;
	vm->GetEnv((void **)&env, JNI_VERSION_1_6);
	vm->AttachCurrentThread(&env, NULL);
	jclass cls = env->GetObjectClass(g_App->activity->clazz);
	jmethodID mid = env->GetMethodID(cls, "pollUnicodeChar", "()I");
	if (!mid)
	{
		vm->DetachCurrentThread();
		return -1;
	}

	ImGuiIO & io = ImGui::GetIO();
	jint c;
	while ((c = env->CallIntMethod(g_App->activity->clazz, mid)) != 0)
		io.AddInputCharacter(c);

	vm->DetachCurrentThread();
	return 0;
}