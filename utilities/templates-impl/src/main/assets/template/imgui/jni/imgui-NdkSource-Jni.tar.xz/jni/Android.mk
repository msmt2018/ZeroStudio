LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE    := ImGuiExample


LOCAL_CFLAGS := -Wno-error=format-security -w
LOCAL_CFLAGS += -fno-rtti -fno-exceptions -fpermissive -fvisibility=hidden
LOCAL_CFLAGS += -std=c11

LOCAL_CPPFLAGS := -Wno-error=format-security -fpermissive -w
LOCAL_CPPFLAGS += -fno-rtti -fno-exceptions -fms-extensions
LOCAL_CPPFLAGS += -Wno-error=c++11-narrowing -fvisibility=hidden
LOCAL_CPPFLAGS += -std=c++17

LOCAL_C_INCLUDES += $(LOCAL_PATH)/imgui
LOCAL_C_INCLUDES += $(LOCAL_PATH)/imgui/font
LOCAL_C_INCLUDES += $(LOCAL_PATH)/imgui/backends
LOCAL_C_INCLUDES += $(LOCAL_PATH)/native_app_glue
LOCAL_C_INCLUDES += $(LOCAL_PATH)/imgui/stb_image
LOCAL_C_INCLUDES += $(LOCAL_PATH)/imgui/图片

LOCAL_SRC_FILES := main.cpp
LOCAL_SRC_FILES += native_app_glue/android_native_app_glue.c
LOCAL_SRC_FILES += \
  imgui/imgui.cpp \
  imgui/imgui_demo.cpp \
  imgui/imgui_draw.cpp \
  imgui/imgui_tables.cpp \
  imgui/imgui_widgets.cpp \
  imgui/backends/imgui_impl_android.cpp \
  imgui/backends/imgui_impl_opengl3.cpp \



LOCAL_LDFLAGS += -llog -lEGL -lGLESv2 -lGLESv3 -landroid

include $(BUILD_SHARED_LIBRARY)
