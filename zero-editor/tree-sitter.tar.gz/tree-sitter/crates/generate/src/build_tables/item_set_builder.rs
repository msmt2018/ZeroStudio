use std::hash::{BuildHasher as _, Hash};

use hashbrown::{HashTable, hash_table};
use rustc_hash::{FxBuildHasher, FxHashMap, FxHashSet};

use super::item::{
    ItemKeyMap, ParseItem, ParseItemDisplay, ParseItemSet, ParseItemSetEntry, TokenSetDisplay,
};
use crate::{
    bitvec::{BitVec, SetBitsIter},
    build_tables::item::{LookaheadSetId, LookaheadSetPool},
    grammars::{
        InlinedProductionMap, LexicalGrammar, ProductionStep, ReservedWordSetId, SyntaxGrammar,
    },
    rules::{NonTerminalIndex, Symbol, SymbolView, TokenSet},
    strpool::StrPool,
};

#[derive(Clone, Copy, Debug)]
struct TransitiveClosureAddition<'a> {
    item: ParseItem<'a>,
    info: AdditionInfo,
    /// `item`'s rank, which locates its entry in a closure.
    rank: FirstStepRank,
}

/// [`FollowSetInfo`] with an interned lookahead set and word-token membership precomputed.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
struct AdditionInfo {
    lookaheads: LookaheadSetId,
    reserved_lookaheads: ReservedWordSetId,
    propagates_lookaheads: bool,
    contains_word: bool,
}

/// the mutable accumulator for a non-terminal's follow set. `lookaheads` is a
/// working `TokenSet` that can be unioned incrementally during traversal, to be
/// interned into [`AdditionInfo`] once complete.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
struct FollowSetInfo {
    lookaheads: TokenSet,
    reserved_lookaheads: ReservedWordSetId,
    propagates_lookaheads: bool,
}

pub struct ParseItemSetBuilder<'a> {
    syntax_grammar: &'a SyntaxGrammar,
    first_sets: FxHashMap<Symbol, TokenSet>,
    /// Each FIRST set interned, for closure propagation by id
    first_set_ids: FxHashMap<Symbol, LookaheadSetId>,
    reserved_first_sets: FxHashMap<Symbol, ReservedWordSetId>,
    last_sets: FxHashMap<Symbol, TokenSet>,
    inlines: &'a InlinedProductionMap,
    pub key_map: &'a ItemKeyMap,
    pub lookaheads: LookaheadSetPool,
    transitive_closure_additions: Vec<Vec<TransitiveClosureAddition<'a>>>,
    /// Scratch for [`Self::transitive_closure`].
    closure_scratch: ClosureEntries<'a>,
}

/// Pushes `value` unless `vector` already has it. `indices` holds the positions
/// of `vector`'s elements, by hash.
fn push_unique<T: Eq + Hash>(vector: &mut Vec<T>, indices: &mut HashTable<u32>, value: T) {
    let hash = FxBuildHasher.hash_one(&value);
    if let hash_table::Entry::Vacant(entry) = indices.entry(
        hash,
        |&index| vector[index as usize] == value,
        |&index| FxBuildHasher.hash_one(&vector[index as usize]),
    ) {
        entry.insert(vector.len() as u32);
        vector.push(value);
    }
}

/// An item's position among all the items that a closure can hold at their first step
/// (`step_index` 0), in item order. See [`FirstStepRanks`].
#[derive(Clone, Copy, Debug)]
struct FirstStepRank(u32);

impl FirstStepRank {
    const fn index(self) -> usize {
        self.0 as usize
    }
}

/// Everything that `ParseItem`'s `Eq` and `Ord` compare between items at their first step,
/// which have nothing before their dot. The fields are declared in the order that `Ord`
/// compares them, so the derived `Ord` orders keys the way it orders their items.
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
struct FirstStepKey {
    variable_index: u32,
    /// `keys[0].cmp`.
    cmp: u32,
}

impl FirstStepKey {
    fn new(item: &ParseItem) -> Self {
        // INVARIANT: only items at their first step are ranked
        assert!(item.step_index == 0 && !item.has_preceding_inherited_fields);
        Self {
            variable_index: item.variable_index,
            cmp: item.keys[0].cmp,
        }
    }
}

/// The [`FirstStepRank`] of every item that a closure can hold at its first step, by key.
#[derive(Default)]
struct FirstStepRanks(FxHashMap<FirstStepKey, FirstStepRank>);

impl FirstStepRanks {
    /// Ranks `items`, which are all at their first step.
    fn new<'a>(items: impl Iterator<Item = ParseItem<'a>>) -> Self {
        let mut keys = items
            .map(|item| FirstStepKey::new(&item))
            .collect::<Vec<_>>();
        keys.sort_unstable();
        keys.dedup();
        Self(
            keys.into_iter()
                .enumerate()
                .map(|(rank, key)| (key, FirstStepRank(rank as u32)))
                .collect(),
        )
    }

    fn len(&self) -> usize {
        self.0.len()
    }

    /// The rank of `item`, which must be one of the items these were built from.
    fn rank(&self, item: &ParseItem) -> FirstStepRank {
        // INVARIANT: every item at its first step has a rank
        *self.0.get(&FirstStepKey::new(item)).unwrap()
    }
}

/// The entries of a closure while [`ParseItemSetBuilder::transitive_closure`] builds it:
/// found by item as they're added, and taken out in item order once it's complete.
///
/// Items are ordered by `step_index` first, so the items at their first step come before
/// all the others. Most of a closure's items are at their first step, and each of those has
/// a [`FirstStepRank`] and a slot for its entry. The rest are kernel items past their first
/// step, which are found by hash and sorted.
#[derive(Default)]
struct ClosureEntries<'a> {
    /// The rank of every item that can be in `first_step`.
    ranks: FirstStepRanks,
    /// The entry of each first-step item in the closure, by rank.
    first_step: Vec<Option<ParseItemSetEntry<'a>>>,
    /// The ranks that have an entry in `first_step`, to find those without scanning it.
    occupied: BitVec,
    /// The number of entries in `first_step`.
    first_step_len: usize,
    /// The entries of the items past their first step, in the order they were added.
    later: Vec<ParseItemSetEntry<'a>>,
    /// The positions of `later`'s entries, by the hash of their items.
    later_indices: HashTable<u32>,
}

impl<'a> ClosureEntries<'a> {
    fn new(ranks: FirstStepRanks) -> Self {
        let mut occupied = BitVec::new();
        occupied.resize(ranks.len(), false);
        Self {
            first_step: vec![None; ranks.len()],
            ranks,
            occupied,
            first_step_len: 0,
            later: Vec::new(),
            later_indices: HashTable::new(),
        }
    }

    /// The entry of `addition`'s item, added if it's new.
    #[inline]
    fn addition_entry(
        &mut self,
        addition: &TransitiveClosureAddition<'a>,
    ) -> &mut ParseItemSetEntry<'a> {
        self.first_step_entry(addition.rank, addition.item)
    }

    /// The entry of `item`, from the closure's kernel, added if it's new.
    fn kernel_entry(&mut self, item: ParseItem<'a>) -> &mut ParseItemSetEntry<'a> {
        // A kernel's items are past their first step, except for the start item.
        if item.step_index == 0 {
            let rank = self.ranks.rank(&item);
            self.first_step_entry(rank, item)
        } else {
            self.later_entry(item)
        }
    }

    /// The entry of `item`, which is at its first step and has the given rank, added if it's
    /// new.
    #[inline]
    fn first_step_entry(
        &mut self,
        rank: FirstStepRank,
        item: ParseItem<'a>,
    ) -> &mut ParseItemSetEntry<'a> {
        let slot = &mut self.first_step[rank.index()];
        if slot.is_none() {
            self.occupied.set(rank.index(), true);
            self.first_step_len += 1;
        }
        slot.get_or_insert_with(|| Self::new_entry(item))
    }

    /// The entry of `item`, which is past its first step, added if it's new.
    fn later_entry(&mut self, item: ParseItem<'a>) -> &mut ParseItemSetEntry<'a> {
        let later = &mut self.later;
        let index = match self.later_indices.entry(
            FxBuildHasher.hash_one(item),
            |&index| later[index as usize].item == item,
            |&index| FxBuildHasher.hash_one(later[index as usize].item),
        ) {
            hash_table::Entry::Occupied(entry) => *entry.get(),
            hash_table::Entry::Vacant(entry) => {
                let index = later.len() as u32;
                entry.insert(index);
                later.push(Self::new_entry(item));
                index
            }
        };
        &mut later[index as usize]
    }

    /// An entry for `item`, with no lookaheads yet.
    fn new_entry(item: ParseItem<'a>) -> ParseItemSetEntry<'a> {
        ParseItemSetEntry {
            item,
            lookaheads: LookaheadSetPool::EMPTY,
            following_reserved_word_set: ReservedWordSetId::default(),
        }
    }

    /// Takes the entries out in item order, leaving this empty for the next closure.
    fn take_item_set(&mut self) -> ParseItemSet<'a> {
        let mut entries = Vec::with_capacity(self.first_step_len + self.later.len());
        let first_step = &mut self.first_step;
        entries.extend(SetBitsIter::new(self.occupied.as_slice()).map(|rank| {
            // INVARIANT: occupied ranks have entries
            first_step[rank].take().unwrap()
        }));
        self.occupied.unset_all();
        self.first_step_len = 0;
        // Past their first step, these all come after the entries above.
        self.later.sort_unstable_by(|a, b| a.item.cmp(&b.item));
        entries.append(&mut self.later);
        self.later_indices.clear();
        ParseItemSet { entries }
    }
}

impl<'a> ParseItemSetBuilder<'a> {
    #[must_use]
    pub fn new(
        syntax_grammar: &'a SyntaxGrammar,
        lexical_grammar: &'a LexicalGrammar,
        inlines: &'a InlinedProductionMap,
        key_map: &'a ItemKeyMap,
    ) -> Self {
        let mut result = Self {
            syntax_grammar,
            first_sets: FxHashMap::default(),
            first_set_ids: FxHashMap::default(),
            reserved_first_sets: FxHashMap::default(),
            last_sets: FxHashMap::default(),
            inlines,
            key_map,
            lookaheads: LookaheadSetPool::new(),
            transitive_closure_additions: Vec::new(),
            closure_scratch: ClosureEntries::default(),
        };

        // For each grammar symbol, populate the FIRST and LAST sets: the set of
        // terminals that appear at the beginning and end that symbol's productions,
        // respectively.
        // For a terminal symbol, the FIRST and LAST sets just consist of the
        // terminal itself.
        let n_terminals = lexical_grammar.variables.len();
        let n_externals = syntax_grammar.external_tokens.len();

        for i in 0..n_terminals {
            let symbol = Symbol::terminal(i);
            let mut set = TokenSet::with_capacity(n_terminals, n_externals);
            set.insert(symbol);
            result.first_sets.insert(symbol, set.clone());
            result.last_sets.insert(symbol, set);
            result
                .reserved_first_sets
                .insert(symbol, ReservedWordSetId::default());
        }

        for i in 0..n_externals {
            let symbol = Symbol::external(i);
            let mut set = TokenSet::with_capacity(n_terminals, n_externals);
            set.insert(symbol);
            result.first_sets.insert(symbol, set.clone());
            result.last_sets.insert(symbol, set);
            result
                .reserved_first_sets
                .insert(symbol, ReservedWordSetId::default());
        }

        // The FIRST set of a non-terminal `i` is the union of the FIRST sets
        // of all the symbols that appear at the beginnings of i's productions. Some
        // of these symbols may themselves be non-terminals, so this is a recursive
        // definition.
        //
        // Rather than computing these sets using recursion, we use an explicit stack
        // called `symbols_to_process`.
        let mut symbols_to_process = Vec::new();
        let mut processed_non_terminals = FxHashSet::<NonTerminalIndex>::default();
        for i in 0..syntax_grammar.variables.len() {
            let root_index = NonTerminalIndex::new(i as u32);
            let symbol = Symbol::non_terminal(i);
            let first_set = result.first_sets.entry(symbol).or_default();
            let reserved_first_set = result.reserved_first_sets.entry(symbol).or_default();

            processed_non_terminals.clear();
            symbols_to_process.clear();
            symbols_to_process.push(root_index);
            while let Some(index) = symbols_to_process.pop() {
                for prod_id in syntax_grammar.variable_prod_ids(usize::from(index)) {
                    if let Some(step) = syntax_grammar.production(prod_id).steps.first() {
                        let symbol = step.symbol();
                        match symbol.view() {
                            SymbolView::Terminal(_) | SymbolView::External(_) => {
                                first_set.insert(symbol);
                            }
                            SymbolView::NonTerminal(index) => {
                                if processed_non_terminals.insert(index) {
                                    symbols_to_process.push(index);
                                }
                            }
                            SymbolView::End | SymbolView::EndOfNonTerminalExtra => unreachable!(),
                        }
                        *reserved_first_set =
                            (*reserved_first_set).max(ReservedWordSetId(u32::from(step.reserved)));
                    }
                }
            }

            // The LAST set is defined in a similar way to the FIRST set.
            let last_set = result.last_sets.entry(symbol).or_default();
            processed_non_terminals.clear();
            symbols_to_process.clear();
            symbols_to_process.push(root_index);
            while let Some(index) = symbols_to_process.pop() {
                for prod_id in syntax_grammar.variable_prod_ids(usize::from(index)) {
                    if let Some(step) = syntax_grammar.production(prod_id).steps.last() {
                        let symbol = step.symbol();
                        match symbol.view() {
                            SymbolView::Terminal(_) | SymbolView::External(_) => {
                                last_set.insert(symbol);
                            }
                            SymbolView::NonTerminal(index) => {
                                if processed_non_terminals.insert(index) {
                                    symbols_to_process.push(index);
                                }
                            }
                            SymbolView::End | SymbolView::EndOfNonTerminalExtra => unreachable!(),
                        }
                    }
                }
            }
        }

        // Intern each FIRST set so closure propagation can union by id.
        for (symbol, set) in &result.first_sets {
            result
                .first_set_ids
                .insert(*symbol, result.lookaheads.intern_ref(set));
        }

        // To compute an item set's transitive closure, we find each item in the set
        // whose next symbol is a non-terminal, and we add new items to the set for
        // each of that symbol's productions. These productions might themselves begin
        // with non-terminals, so the process continues recursively. In this process,
        // the total set of entries that get added depends only on two things:
        //
        //   * the non-terminal symbol that occurs next in each item
        //
        //   * the set of terminals that can follow that non-terminal symbol in the item
        //
        // So we can avoid a lot of duplicated recursive work by precomputing, for each
        // non-terminal symbol `i`, a final list of *additions* that must be made to an
        // item set when symbol `i` occurs as the next symbol in one if its core items.
        // The structure of a precomputed *addition* is as follows:
        //
        //   * `item` - the new item that must be added as part of the expansion of the symbol `i`.
        //
        //   * `lookaheads` - the set of possible lookahead tokens that can always come after `item`
        //     in an expansion of symbol `i`.
        //
        //   * `reserved_lookaheads` - the set of reserved lookahead tokens that can always come
        //     after `item` in the expansion of symbol `i`.
        //
        //   * `propagates_lookaheads` - a boolean indicating whether or not `item` can occur at the
        //     *end* of the expansion of symbol `i`, so that i's own current lookahead tokens can
        //     occur after `item`.
        //
        // Rather than computing these additions recursively, we use an explicit stack.
        let empty_lookaheads = TokenSet::new();
        let mut eof_lookaheads = TokenSet::new();
        eof_lookaheads.insert(Symbol::End);
        let mut stack = Vec::new();
        let mut follow_set_info_by_non_terminal = FxHashMap::<usize, FollowSetInfo>::default();
        let mut additions = vec![Vec::new(); syntax_grammar.variables.len()];
        let mut addition_indices = HashTable::new();
        for (i, additions_for_non_terminal) in additions.iter_mut().enumerate() {
            // First, build up a map whose keys are all of the non-terminals that can
            // appear at the beginning of non-terminal `i`, and whose values store
            // information about the tokens that can follow those non-terminals.
            stack.clear();
            stack.push((i, &empty_lookaheads, ReservedWordSetId::default(), true));
            follow_set_info_by_non_terminal.clear();
            while let Some((sym_ix, lookaheads, reserved_word_set_id, propagates_lookaheads)) =
                stack.pop()
            {
                let mut did_add = false;
                let info = follow_set_info_by_non_terminal.entry(sym_ix).or_default();
                did_add |= info.lookaheads.insert_all(lookaheads);
                if reserved_word_set_id > info.reserved_lookaheads {
                    info.reserved_lookaheads = reserved_word_set_id;
                    did_add = true;
                }
                did_add |= propagates_lookaheads && !info.propagates_lookaheads;
                info.propagates_lookaheads |= propagates_lookaheads;
                if !did_add {
                    continue;
                }

                for prod_id in syntax_grammar.variable_prod_ids(sym_ix) {
                    let production = syntax_grammar.production(prod_id);
                    if let Some(index) = production
                        .first_symbol()
                        .and_then(Symbol::non_terminal_index)
                    {
                        let index = usize::from(index);
                        if let Some(next_step) = production.steps.get(1) {
                            stack.push((
                                index,
                                &result.first_sets[&next_step.symbol()],
                                result.reserved_first_sets[&next_step.symbol()],
                                false,
                            ));
                        } else if production.requires_eof_lookahead {
                            stack.push((
                                index,
                                &eof_lookaheads,
                                ReservedWordSetId::default(),
                                false,
                            ));
                        } else {
                            stack.push((
                                index,
                                lookaheads,
                                reserved_word_set_id,
                                propagates_lookaheads,
                            ));
                        }
                    }
                }
            }

            // Store all of those non-terminals' productions, along with their associated
            // lookahead info, as *additions* associated with non-terminal `i`.
            addition_indices.clear();
            for (&variable_index, follow_set_info) in &follow_set_info_by_non_terminal {
                let non_terminal = Symbol::non_terminal(variable_index);
                if syntax_grammar.variables_to_inline.contains(&non_terminal) {
                    continue;
                }
                let info = AdditionInfo {
                    lookaheads: result.lookaheads.intern_ref(&follow_set_info.lookaheads),
                    reserved_lookaheads: follow_set_info.reserved_lookaheads,
                    propagates_lookaheads: follow_set_info.propagates_lookaheads,
                    contains_word: syntax_grammar
                        .word_token
                        .is_some_and(|w| follow_set_info.lookaheads.contains(w)),
                };
                for prod_id in syntax_grammar.variable_prod_ids(variable_index) {
                    let item = ParseItem {
                        variable_index: variable_index as u32,
                        prod_id,
                        keys: key_map.keys_for(prod_id),
                        step_index: 0,
                        has_preceding_inherited_fields: false,
                    };

                    if let Some(ids) = inlines.inlined_prod_ids(item.prod_id, item.step_index) {
                        for &id in ids {
                            let mut item_info = info;
                            if syntax_grammar.production(id).requires_eof_lookahead {
                                item_info.lookaheads =
                                    result.lookaheads.intern_ref(&eof_lookaheads);
                                item_info.reserved_lookaheads = ReservedWordSetId::default();
                                item_info.propagates_lookaheads = false;
                                item_info.contains_word = false;
                            }
                            push_unique(
                                additions_for_non_terminal,
                                &mut addition_indices,
                                (
                                    item.substitute_production(id, key_map.keys_for(id)),
                                    item_info,
                                ),
                            );
                        }
                    } else {
                        let mut item_info = info;
                        if syntax_grammar.production(prod_id).requires_eof_lookahead {
                            item_info.lookaheads = result.lookaheads.intern_ref(&eof_lookaheads);
                            item_info.reserved_lookaheads = ReservedWordSetId::default();
                            item_info.propagates_lookaheads = false;
                            item_info.contains_word = false;
                        }
                        push_unique(
                            additions_for_non_terminal,
                            &mut addition_indices,
                            (item, item_info),
                        );
                    }
                }
            }
        }

        // Besides these additions, the only item a closure holds at its first step is the start
        // item, in the start state's kernel.
        let ranks = FirstStepRanks::new(
            additions
                .iter()
                .flatten()
                .map(|&(item, _)| item)
                .chain(std::iter::once(ParseItem::start(key_map))),
        );
        result.transitive_closure_additions = additions
            .into_iter()
            .map(|additions_for_non_terminal| {
                additions_for_non_terminal
                    .into_iter()
                    .map(|(item, info)| TransitiveClosureAddition {
                        item,
                        info,
                        rank: ranks.rank(&item),
                    })
                    .collect()
            })
            .collect();
        result.closure_scratch = ClosureEntries::new(ranks);

        result
    }

    #[must_use]
    pub fn transitive_closure(&mut self, item_set: &ParseItemSet<'a>) -> ParseItemSet<'a> {
        for entry in &item_set.entries {
            if let Some(ids) = self
                .inlines
                .inlined_prod_ids(entry.item.prod_id, entry.item.step_index)
            {
                for &id in ids {
                    self.add_item(&ParseItemSetEntry {
                        item: entry
                            .item
                            .substitute_production(id, self.key_map.keys_for(id)),
                        lookaheads: entry.lookaheads,
                        following_reserved_word_set: entry.following_reserved_word_set,
                    });
                }
            } else {
                self.add_item(entry);
            }
        }

        self.closure_scratch.take_item_set()
    }

    #[must_use]
    pub fn first_set(&self, symbol: Symbol) -> &TokenSet {
        &self.first_sets[&symbol]
    }

    #[must_use]
    pub fn reserved_first_set(&self, symbol: Symbol) -> Option<&TokenSet> {
        let id = *self.reserved_first_sets.get(&symbol)?;
        Some(&self.syntax_grammar.reserved_word_sets[id.0 as usize])
    }

    #[must_use]
    pub fn last_set(&self, symbol: Symbol) -> &TokenSet {
        &self.last_sets[&symbol]
    }

    fn add_item(&mut self, entry: &ParseItemSetEntry<'a>) {
        if let Some(index) = entry
            .item
            .step(self.syntax_grammar)
            .and_then(ProductionStep::non_terminal_index)
        {
            let next_step = entry.item.successor().step(self.syntax_grammar);

            // Determine which tokens can follow this non-terminal.
            let (following_tokens, following_reserved_tokens) = if let Some(next_step) = next_step {
                let key = next_step.symbol();
                (self.first_set_ids[&key], self.reserved_first_sets[&key])
            } else {
                (entry.lookaheads, entry.following_reserved_word_set)
            };

            // Use the pre-computed *additions* to expand the non-terminal.
            for addition in &self.transitive_closure_additions[usize::from(index)] {
                let e = self.closure_scratch.addition_entry(addition);
                e.lookaheads = self
                    .lookaheads
                    .union(e.lookaheads, addition.info.lookaheads);

                if addition.info.contains_word {
                    e.following_reserved_word_set = e
                        .following_reserved_word_set
                        .max(addition.info.reserved_lookaheads);
                }

                if addition.info.propagates_lookaheads {
                    e.lookaheads = self.lookaheads.union(e.lookaheads, following_tokens);

                    if let Some(word_token) = self.syntax_grammar.word_token
                        && self.lookaheads.get(following_tokens).contains(word_token)
                    {
                        e.following_reserved_word_set =
                            e.following_reserved_word_set.max(following_reserved_tokens);
                    }
                }
            }
        }

        let e = self.closure_scratch.kernel_entry(entry.item);
        e.lookaheads = self.lookaheads.union(e.lookaheads, entry.lookaheads);
        e.following_reserved_word_set = e
            .following_reserved_word_set
            .max(entry.following_reserved_word_set);
    }
}

#[expect(dead_code, reason = "Debugging aid")]
struct ParseItemSetBuilderDisplay<'a>(
    pub &'a ParseItemSetBuilder<'a>,
    pub &'a LexicalGrammar,
    pub &'a StrPool,
);

impl std::fmt::Debug for ParseItemSetBuilderDisplay<'_> {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        writeln!(f, "ParseItemSetBuilder {{")?;

        writeln!(f, "  first_sets: {{")?;
        for (symbol, first_set) in &self.0.first_sets {
            let name = match symbol.view() {
                SymbolView::NonTerminal(index) => self
                    .2
                    .resolve(self.0.syntax_grammar.variables[usize::from(index)].name),
                SymbolView::External(index) => self
                    .2
                    .resolve(self.0.syntax_grammar.external_tokens[usize::from(index)].name),
                SymbolView::Terminal(index) => {
                    self.2.resolve(self.1.variables[usize::from(index)].name)
                }
                SymbolView::End => "<EOF>",
                SymbolView::EndOfNonTerminalExtra => "<END_OF_NONTERMINAL_EXTRA>",
            };
            writeln!(
                f,
                "    first({name:?}): {}",
                TokenSetDisplay(first_set, self.0.syntax_grammar, self.1, self.2)
            )?;
        }
        writeln!(f, "  }}")?;

        writeln!(f, "  last_sets: {{")?;
        for (symbol, last_set) in &self.0.last_sets {
            let name = match symbol.view() {
                SymbolView::NonTerminal(index) => self
                    .2
                    .resolve(self.0.syntax_grammar.variables[usize::from(index)].name),
                SymbolView::External(index) => self
                    .2
                    .resolve(self.0.syntax_grammar.external_tokens[usize::from(index)].name),
                SymbolView::Terminal(index) => {
                    self.2.resolve(self.1.variables[usize::from(index)].name)
                }
                SymbolView::End => "<EOF>",
                SymbolView::EndOfNonTerminalExtra => "<END_OF_NONTERMINAL_EXTRA>",
            };
            writeln!(
                f,
                "    last({name:?}): {}",
                TokenSetDisplay(last_set, self.0.syntax_grammar, self.1, self.2)
            )?;
        }
        writeln!(f, "  }}")?;

        writeln!(f, "  additions: {{")?;
        for (i, variable) in self.0.syntax_grammar.variables.iter().enumerate() {
            writeln!(f, "    {}: {{", self.2.resolve(variable.name))?;
            for addition in &self.0.transitive_closure_additions[i] {
                writeln!(
                    f,
                    "      {}",
                    ParseItemDisplay(&addition.item, self.0.syntax_grammar, self.1, self.2)
                )?;
            }
            writeln!(f, "    }},")?;
        }
        write!(f, "  }},")?;

        write!(f, "}}")?;
        Ok(())
    }
}
